package com.example.kiano

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
