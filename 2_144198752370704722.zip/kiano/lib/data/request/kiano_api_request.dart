class KianoAccessListRequest {
  String phoneNumber;

  KianoAccessListRequest(this.phoneNumber);
}