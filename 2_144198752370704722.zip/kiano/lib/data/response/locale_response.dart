import 'package:freezed_annotation/freezed_annotation.dart';
// part 'locale_response.g.dart';

// @JsonSerializable()
// class PriceLevelsItemResponse {
//   @JsonKey(name: "level")
//   int? level;
//   @JsonKey(name: "ratio")
//   double? ratio;
//
//   PriceLevelsItemResponse(this.level, this.ratio);
//
//   //fromJson
//   factory PriceLevelsItemResponse.fromJson(Map<String, dynamic> json) =>
//       _$PriceLevelsItemFromJson(json);
// }
