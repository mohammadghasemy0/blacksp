class Constant {
  static const String baseUrl = 'http://37.156.14.41:8079';
  static const String japoBaseUrl = 'http://api.sup.kiasystem.ir';
  static const String kianoBaseUrl = 'http://api.sup.kiasystem.ir';
}